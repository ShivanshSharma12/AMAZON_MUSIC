import 'dart:convert';

import 'package:dio/dio.dart';

class SongClient{
  Dio dioClient = Dio();

  getSongsFromTunes() async{
    try{
      String iTunesUrl = "https://itunes.apple.com/search?term=mohit+chauhan&limit=25";
     var res =  await dioClient.get(iTunesUrl);
      Map<String, dynamic> songsMap = jsonDecode(res.data);
     print("this is the response $res");
     print("this is the map response $songsMap");
return songsMap;
     
    }
    catch(error){
      print("some error occured $error");
    }
  }
}