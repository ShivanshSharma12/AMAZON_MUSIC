// import 'package:audioplayers/audioplayers.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';

// class SongPlayer extends StatefulWidget {
//   late String artworkUrl100;
//   late String artistName;
//   late String previewUrl;
//   late String trackName;
//   late bool currentState;



//    SongPlayer({ 
//     required this.artworkUrl100, 
//     required this.artistName, 
//     required this.previewUrl, 
//     required this. trackName, 
//     required this.currentState,
//   super.key});

//   @override
//   State<SongPlayer> createState() => _SongPlayerState();
// }

// class _SongPlayerState extends State<SongPlayer> {
//   AudioPlayer SongPlayer = AudioPlayer();
//   Duration fullDuration = const Duration(seconds: 0);
//   Duration currentDuration = const Duration(seconds: 0);

//   int elapsed = 0;

//   getSongDetails(){
//     SongPlayer.onDurationChanged.listen((Duration fDuration) { 
//       setState(() {
//         fullDuration = fDuration;
//       });
//     });
//     SongPlayer.onPositionChanged.listen((Duration cDuratiom) {
//       setState(() {
//         print("this is the current durtion $cDuratiom");
//         currentDuration = cDuratiom;
//       });
//      });
//      SongPlayer.onPlayerStateChanged.listen((State) { });
//   }

//   @override
//   void initState(){
//     getSongDetails();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//       child: Scaffold(
//         appBar: AppBar(


//       ),
//       body: Column(mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//         SizedBox(
//           width: MediaQuery.of(context).size.width * 0.8,
//         height: MediaQuery.of(context).size.height * 0.5,
//         child: Image.network(widget.artworkUrl100),),

//         Text(widget.trackName),
//         Text(widget.artistName), 
//         Expanded(
//           child: Slider(
//             value: (currentDuration.inSeconds < fullDuration.inSeconds)? (currentDuration.inSeconds/ fullDuration.inSeconds)
//             : 0,

//             onChanged: (Value){}),
//         ),
//         Text(fullDuration.inSeconds.toString()),
//         Row( mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//           children: [
//             IconButton(onPressed: (){}, icon: Icon(Icons.no_accounts), iconSize: 20,),
//             IconButton(onPressed: (){}, icon: Icon(Icons.skip_previous), iconSize: 20,),
//             IconButton(onPressed: (){ widget.currentState
//             ? SongPlayer.stop()
//               : SongPlayer.play(UrlSource(widget.previewUrl));

//               widget.currentState = !widget.currentState;
//               }, 
//               icon: const Icon(Icons.play_arrow),iconSize: 50,),
//             IconButton(onPressed: (){}, icon: Icon(Icons.skip_next),iconSize: 20,),
//             IconButton(onPressed: (){}, icon: Icon(Icons.repeat),iconSize: 20,),


//           ],
//         )
//       ]),));
//   }
// }

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';

class SongPlayer extends StatefulWidget {
  late String artWorkUrl;
  late String trackName;
  late String artistName;
  late String previewUrl;
  late bool currentStat;
  late PlayerState playerState;
  SongPlayer(
      {required this.artWorkUrl,
      required this.artistName,
      required this.previewUrl,
      required this.trackName,
      required this.currentStat,
      // required this.playerState,
      super.key});

  @override
  State<SongPlayer> createState() => _SongPlayerState();
}

class _SongPlayerState extends State<SongPlayer> {
  AudioPlayer songPlayer = AudioPlayer();
  Duration fullDuration = const Duration(seconds: 0);
  Duration currentDuration = const Duration(seconds: 0);

  int elapsed = 0;

  getSongDetails() {
    songPlayer.onDurationChanged.listen((Duration fDuration) {
      setState(() {
        fullDuration = fDuration;
      });
    });
    songPlayer.onPositionChanged.listen((Duration cDuration) {
      setState(() {
        print("this is the current duration $cDuration");
        currentDuration = cDuration;
      });
    });
    songPlayer.onPlayerStateChanged.listen((PlayerState state) {
      print("this is the current state $state");
      setState(() {
        
        
      });
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    getSongDetails();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(15),
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height * 0.5,
            child: Image.network(
              widget.artWorkUrl,
              fit: BoxFit.cover,
            ),
          ),
          Text(
            widget.trackName,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(
            height: 10,
          ),
          Text(
            widget.artistName,
            style: const TextStyle(
                fontSize: 15, fontWeight: FontWeight.bold, color: Colors.grey),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 15.0, right: 15.0),
            child: Row(
              children: [
                Text(
                  currentDuration.inSeconds.toString(),
                  style: const TextStyle(fontSize: 30),
                ),
                Expanded(
                  child: Slider(
                      value: (currentDuration.inSeconds <
                              fullDuration.inSeconds)
                          ? (currentDuration.inSeconds / fullDuration.inSeconds)
                          : 0,
                      onChanged: (value) {
                        print("this is the req value $value");
                        int reqDuration = (value*fullDuration.inSeconds).toInt();
                        songPlayer.seek(Duration(seconds: reqDuration));
                        setState(() {
                          
                        });
                        
                      }),
                ),
                Text(fullDuration.inSeconds.toString()),
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              IconButton(onPressed: () {}, icon: const Icon(Icons.no_accounts)),
              IconButton(
                  onPressed: () {}, icon: const Icon(Icons.skip_previous)),
              IconButton(
                  iconSize: 60,
                  padding: EdgeInsets.zero,
                  onPressed: () {
                    widget.currentStat
                    ? songPlayer.stop()
                    : songPlayer.play(UrlSource(widget.previewUrl));

                    widget.currentStat= !widget.currentStat;
                    setState(() {
                      
                    });
                  },
                  icon:  Icon(widget.currentStat ? Icons.pause : Icons.play_arrow)
                   
                    // size: 80,
                  ),
              IconButton(onPressed: () {}, icon: const Icon(Icons.skip_next)),
              IconButton(onPressed: () {}, icon: const Icon(Icons.repeat)),
            ],
          ),
        ],
      ),
    ));
  }
}