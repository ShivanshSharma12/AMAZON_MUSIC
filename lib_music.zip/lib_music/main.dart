// import 'dart:js';

import 'package:flutter/material.dart';
import 'package:sangeet_app/screens/homescreen.dart';
import 'package:sangeet_app/screens/loadingpage.dart';

void main(){
  runApp(MaterialApp(
    // home:  LoadingScreen(),
    initialRoute: '/',
    routes: {
      '/': (context) => const LoadingScreen(),
      '/home':(context) => const HomePage()
    },
  ));
}